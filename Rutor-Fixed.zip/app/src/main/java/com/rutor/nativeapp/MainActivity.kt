package com.rutor.nativeapp

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.net.URLEncoder
import java.util.concurrent.Executors

private const val BASE = "https://rutor.info"
private val BG = Color.rgb(16, 17, 20)
private val PANEL = Color.rgb(29, 31, 37)
private val TEXT = Color.rgb(239, 240, 243)
private val MUTED = Color.rgb(155, 160, 170)
private val RED = Color.rgb(229, 57, 53)

 data class TorrentItem(
    val title: String,
    val url: String,
    val size: String,
    val seeds: String,
    val leeches: String,
    val date: String,
    val magnet: String = "",
    val torrentUrl: String = ""
)

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var query: EditText
    private lateinit var category: Spinner
    private val favorites = linkedSetOf<String>()
    private var currentItems = listOf<TorrentItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()
        loadHome()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(12)); setBackgroundColor(BG)
        }
        val logo = TextView(this).apply { text = "RUTOR"; textSize = 25f; setTextColor(RED); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        header.addView(logo, LinearLayout.LayoutParams(0, -2, 1f))
        val fav = TextView(this).apply { text = "★"; textSize = 27f; setTextColor(TEXT); setPadding(dp(12), 0, dp(4), 0); setOnClickListener { showFavorites() } }
        header.addView(fav)
        root.addView(header)

        val searchPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(12)); setBackgroundColor(PANEL)
        }
        query = EditText(this).apply {
            hint = "Поиск раздач (от 3 символов)"; setHintTextColor(MUTED); setTextColor(TEXT)
            textSize = 16f; setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(14), dp(12), dp(14), dp(12)); setBackgroundColor(Color.rgb(42,44,51))
            setOnEditorActionListener { _, action, _ -> if (action == EditorInfo.IME_ACTION_SEARCH) { search(); true } else false }
        }
        searchPanel.addView(query, LinearLayout.LayoutParams(-1, dp(50)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(9), 0, 0) }
        category = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Все категории", "Фильмы", "Сериалы", "Музыка", "Игры", "Софт", "Картинки", "Аниме", "Книги"))
        }
        row.addView(category, LinearLayout.LayoutParams(0, dp(46), 1f))
        val go = Button(this).apply { text = "НАЙТИ"; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED)); setOnClickListener { search() } }
        row.addView(go, LinearLayout.LayoutParams(dp(112), dp(46)))
        searchPanel.addView(row)
        root.addView(searchPanel)

        val caption = TextView(this).apply { text = "ПОСЛЕДНИЕ РАЗДАЧИ"; setTextColor(MUTED); textSize = 11f; letterSpacing = .12f; setPadding(dp(18), dp(16), dp(18), dp(8)) }
        root.addView(caption)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(12), dp(16)) }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = TextView(this).apply {
            text = "Главная     •     Избранное     •     О RUTOR"; gravity = Gravity.CENTER
            setTextColor(MUTED); textSize = 12f; setPadding(dp(12), dp(13), dp(12), dp(13)); setBackgroundColor(PANEL)
            setOnClickListener { showAbout() }
        }
        root.addView(bottom)
        setContentView(root)
    }

    private fun search() {
        val q = query.text.toString().trim()
        if (q.length < 3) { toast("Введите минимум 3 символа"); return }
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(query.windowToken, 0)
        val cat = intArrayOf(0,1,6,2,8,9,3,10,11)[category.selectedItemPosition]
        val encoded = URLEncoder.encode(q, "UTF-8").replace("+", "%20")
        fetch("$BASE/search/0/$cat/100/2/$encoded", "РЕЗУЛЬТАТЫ ПОИСКА")
    }

    private fun loadHome() = fetch("$BASE/", "ПОСЛЕДНИЕ РАЗДАЧИ")

    private fun fetch(url: String, title: String) {
        list.removeAllViews(); message("Загружаем Rutor…")
        executor.execute {
            try {
                val doc = Jsoup.connect(url).userAgent("Mozilla/5.0 (Linux; Android 17) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36")
                    .timeout(20000).followRedirects(true).get()
                val found = parseItems(doc)
                runOnUiThread {
                    list.removeAllViews()
                    (root.getChildAt(2) as? TextView)?.text = title
                    currentItems = found
                    if (found.isEmpty()) message("Ничего не найдено. Проверьте соединение или попробуйте позже.")
                    else found.forEach { addTorrentCard(it) }
                }
            } catch (e: Exception) {
                runOnUiThread { list.removeAllViews(); message("Не удалось подключиться к Rutor.\n${e.localizedMessage ?: "Ошибка сети"}") }
            }
        }
    }

    private fun parseItems(doc: org.jsoup.nodes.Document): List<TorrentItem> {
        val out = mutableListOf<TorrentItem>()
        val rows = doc.select("#index table tr, #index tr")
        for (tr in rows) {
            val a = tr.selectFirst("a[href*=/torrent/]") ?: continue
            val href = a.absUrl("href").ifBlank { BASE + a.attr("href") }
            val title = a.text().trim()
            if (title.isBlank()) continue
            val cells = tr.select("td")
            val text = tr.text()
            val size = cells.firstOrNull { it.text().contains(Regex("\\b(KB|MB|GB|TB)\\b", RegexOption.IGNORE_CASE)) }?.text()?.trim() ?: "—"
            val nums = tr.select("a[href*=peer], img[alt]").map { it.parent()?.text()?.trim().orEmpty() }.filter { it.isNotBlank() }
            val peerText = text.substringAfterLast(size, "")
            val counts = Regex("\\b\\d+\\b").findAll(peerText).map { it.value }.toList()
            val date = cells.firstOrNull()?.text()?.trim().orEmpty()
            out.add(TorrentItem(title, href, size, counts.getOrNull(0) ?: "—", counts.getOrNull(1) ?: "—", date))
            if (out.size >= 60) break
        }
        return out.distinctBy { it.url }
    }

    private fun addTorrentCard(item: TorrentItem) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(13), dp(15), dp(13)); setBackgroundColor(PANEL)
        }
        val title = TextView(this).apply { text = item.title; setTextColor(TEXT); textSize = 15f; typeface = android.graphics.Typeface.DEFAULT_BOLD }
        card.addView(title)
        val meta = TextView(this).apply { text = "${item.date}   •   ${item.size}   •   ↑ ${item.seeds}   ↓ ${item.leeches}"; setTextColor(MUTED); textSize = 12f; setPadding(0, dp(8), 0, dp(5)) }
        card.addView(meta)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val details = TextView(this).apply { text = "Подробнее  ›"; setTextColor(RED); textSize = 13f; setPadding(0, dp(8), dp(18), dp(4)); setOnClickListener { showDetails(item) } }
        actions.addView(details)
        val star = TextView(this).apply { text = if (favorites.contains(item.url)) "★" else "☆"; textSize = 22f; setTextColor(if (favorites.contains(item.url)) RED else MUTED); setOnClickListener { if (!favorites.add(item.url)) favorites.remove(item.url); text = if (favorites.contains(item.url)) "★" else "☆"; setTextColor(if (favorites.contains(item.url)) RED else MUTED) } }
        actions.addView(star)
        card.addView(actions)
        list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
    }

    private fun showDetails(item: TorrentItem) {
        executor.execute {
            var magnet = ""; var torrent = ""
            try {
                val doc = Jsoup.connect(item.url).userAgent("Mozilla/5.0 (Android 17)").timeout(20000).get()
                magnet = doc.selectFirst("a[href^=magnet:]")?.attr("href") ?: ""
                torrent = doc.select("a[href]").firstOrNull { it.text().contains("Скачать", true) }?.absUrl("href") ?: ""
            } catch (_: Exception) { }
            val m = magnet; val t = torrent
            runOnUiThread {
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(4)) }
                box.addView(TextView(this).apply { text = item.title; textSize = 17f; setTextColor(TEXT); typeface = android.graphics.Typeface.DEFAULT_BOLD })
                box.addView(TextView(this).apply { text = "\nРазмер: ${item.size}\nСиды: ${item.seeds}   Личи: ${item.leeches}"; setTextColor(MUTED); textSize = 14f })
                val dialog = android.app.AlertDialog.Builder(this).setTitle("Раздача").setView(box)
                    .setPositiveButton("Открыть magnet") { _, _ -> if (m.isNotBlank()) openExternal(m) else toast("Magnet-ссылка не найдена") }
                    .setNeutralButton("Скачать .torrent") { _, _ -> if (t.isNotBlank()) downloadTorrent(t, item.title) else toast("Ссылка на torrent не найдена") }
                    .setNegativeButton("Страница") { _, _ -> openExternal(item.url) }.create()
                dialog.show()
            }
        }
    }

    private fun downloadTorrent(url: String, title: String) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle(title.take(80) + ".torrent")
                .setDescription("Загрузка торрент-файла с Rutor")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "RUTOR_${System.currentTimeMillis()}.torrent")
                .setAllowedOverMetered(true).setAllowedOverRoaming(false)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            toast("Загрузка добавлена. Откройте файл из уведомления или папки Downloads.")
        } catch (e: Exception) { toast("Не удалось начать загрузку: ${e.localizedMessage}") }
    }

    private fun openExternal(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { toast("Не найдено приложение для открытия ссылки") }
    }

    private fun showFavorites() {
        val items = currentItems.filter { favorites.contains(it.url) }
        list.removeAllViews()
        (root.getChildAt(2) as? TextView)?.text = "ИЗБРАННОЕ"
        if (favorites.isEmpty()) message("Пока нет сохранённых раздач")
        else favorites.forEach { url ->
            val item = currentItems.firstOrNull { it.url == url }
            if (item != null) addTorrentCard(item) else {
                val tv = TextView(this).apply { text = url; setTextColor(TEXT); setPadding(dp(12), dp(12), dp(12), dp(12)); setOnClickListener { openExternal(url) } }
                list.addView(tv)
            }
        }
    }

    private fun showAbout() {
        android.app.AlertDialog.Builder(this).setTitle("RUTOR Native")
            .setMessage("Неофициальный клиент-каталог для Rutor. Приложение не размещает файлы и не проверяет содержимое раздач. Загружайте и распространяйте только материалы, на которые у вас есть права.")
            .setPositiveButton("OK", null).show()
    }

    private fun message(s: String) { list.addView(TextView(this).apply { text = s; setTextColor(MUTED); textSize = 14f; gravity = Gravity.CENTER; setPadding(dp(20), dp(34), dp(20), dp(34)) }) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { super.onDestroy(); executor.shutdown() }
}
