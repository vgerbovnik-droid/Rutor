package com.rutor.nativeapp

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.BitmapFactory
import android.os.Build
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher
import android.widget.ImageView
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.net.URLEncoder
import java.util.concurrent.Executors

private const val BASE = "https://rutor.info"
private val BG = Color.rgb(16, 17, 20)
private val PANEL = Color.rgb(29, 31, 37)
private val TEXT = Color.rgb(239, 240, 243)
private val MUTED = Color.rgb(155, 160, 170)
private val RED = Color.rgb(229, 57, 53)

 data class TorrentItem(
    val title: String,
    val url: String,
    val size: String,
    val seeds: String,
    val leeches: String,
    val date: String,
    val magnet: String = "",
    val torrentUrl: String = ""
)

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var query: EditText
    private lateinit var category: Spinner
    private val favorites = linkedSetOf<String>()
    private var currentItems = listOf<TorrentItem>()
    private var detailOpen = false
    private var detailToken = 0
    private lateinit var mainScroll: ScrollView
    private var systemBackCallback: OnBackInvokedCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()
        if (Build.VERSION.SDK_INT >= 33) {
            val callback = OnBackInvokedCallback { if (detailOpen) returnToList() else finish() }
            systemBackCallback = callback
            onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, callback)
        }
        loadHome()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(12)); setBackgroundColor(BG)
        }
        val logo = TextView(this).apply { text = "RUTOR 1.4 TEST"; textSize = 25f; setTextColor(RED); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        header.addView(logo, LinearLayout.LayoutParams(0, -2, 1f))
        val fav = TextView(this).apply { text = "★"; textSize = 27f; setTextColor(TEXT); setPadding(dp(12), 0, dp(4), 0); setOnClickListener { showFavorites() } }
        header.addView(fav)
        root.addView(header)

        val searchPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(12)); setBackgroundColor(PANEL)
        }
        query = EditText(this).apply {
            hint = "Поиск раздач (от 3 символов)"; setHintTextColor(MUTED); setTextColor(TEXT)
            textSize = 16f; setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(14), dp(12), dp(14), dp(12)); setBackgroundColor(Color.rgb(42,44,51))
            setOnEditorActionListener { _, action, _ -> if (action == EditorInfo.IME_ACTION_SEARCH) { search(); true } else false }
        }
        searchPanel.addView(query, LinearLayout.LayoutParams(-1, dp(50)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(9), 0, 0) }
        category = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Все категории", "Фильмы", "Сериалы", "Музыка", "Игры", "Софт", "Картинки", "Аниме", "Книги"))
        }
        row.addView(category, LinearLayout.LayoutParams(0, dp(46), 1f))
        val go = Button(this).apply { text = "НАЙТИ"; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED)); setOnClickListener { search() } }
        row.addView(go, LinearLayout.LayoutParams(dp(112), dp(46)))
        searchPanel.addView(row)
        root.addView(searchPanel)

        val caption = TextView(this).apply { text = "ПОСЛЕДНИЕ РАЗДАЧИ"; setTextColor(MUTED); textSize = 11f; letterSpacing = .12f; setPadding(dp(18), dp(16), dp(18), dp(8)) }
        root.addView(caption)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        mainScroll = scroll
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(12), dp(16)) }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = TextView(this).apply {
            text = "Главная     •     Избранное     •     О RUTOR"; gravity = Gravity.CENTER
            setTextColor(MUTED); textSize = 12f; setPadding(dp(12), dp(13), dp(12), dp(13)); setBackgroundColor(PANEL)
            setOnClickListener { showAbout() }
        }
        root.addView(bottom)
        setContentView(root)
    }

    private fun search() {
        val q = query.text.toString().trim()
        if (q.length < 3) { toast("Введите минимум 3 символа"); return }
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(query.windowToken, 0)
        val cat = intArrayOf(0,1,6,2,8,9,3,10,11)[category.selectedItemPosition]
        val encoded = URLEncoder.encode(q, "UTF-8").replace("+", "%20")
        fetch("$BASE/search/0/$cat/100/2/$encoded", "РЕЗУЛЬТАТЫ ПОИСКА")
    }

    private fun loadHome() = fetch("$BASE/", "ПОСЛЕДНИЕ РАЗДАЧИ")

    private fun fetch(url: String, title: String) {
        list.removeAllViews(); message("Загружаем Rutor…")
        executor.execute {
            try {
                val doc = Jsoup.connect(url).userAgent("Mozilla/5.0 (Linux; Android 17) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36")
                    .timeout(20000).followRedirects(true).get()
                val found = parseItems(doc)
                runOnUiThread {
                    list.removeAllViews()
                    (root.getChildAt(2) as? TextView)?.text = title
                    currentItems = found
                    if (found.isEmpty()) message("Ничего не найдено. Проверьте соединение или попробуйте позже.")
                    else found.forEach { addTorrentCard(it) }
                }
            } catch (e: Exception) {
                runOnUiThread { list.removeAllViews(); message("Не удалось подключиться к Rutor.\n${e.localizedMessage ?: "Ошибка сети"}") }
            }
        }
    }

    private fun parseItems(doc: org.jsoup.nodes.Document): List<TorrentItem> {
        val out = mutableListOf<TorrentItem>()
        val rows = doc.select("#index table tr, #index tr")
        for (tr in rows) {
            val a = tr.selectFirst("a[href*=/torrent/]") ?: continue
            val href = a.absUrl("href").ifBlank { BASE + a.attr("href") }
            val title = a.text().trim()
            if (title.isBlank()) continue
            val cells = tr.select("td")
            val text = tr.text()
            val size = cells.firstOrNull { it.text().contains(Regex("\\b(KB|MB|GB|TB)\\b", RegexOption.IGNORE_CASE)) }?.text()?.trim() ?: "—"
            val nums = tr.select("a[href*=peer], img[alt]").map { it.parent()?.text()?.trim().orEmpty() }.filter { it.isNotBlank() }
            val peerText = text.substringAfterLast(size, "")
            val counts = Regex("\\b\\d+\\b").findAll(peerText).map { it.value }.toList()
            val date = cells.firstOrNull()?.text()?.trim().orEmpty()
            out.add(TorrentItem(title, href, size, counts.getOrNull(0) ?: "—", counts.getOrNull(1) ?: "—", date))
            if (out.size >= 60) break
        }
        return out.distinctBy { it.url }
    }

    private fun addTorrentCard(item: TorrentItem) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(13), dp(15), dp(13)); setBackgroundColor(PANEL)
        }
        val title = TextView(this).apply { text = item.title; setTextColor(TEXT); textSize = 15f; typeface = android.graphics.Typeface.DEFAULT_BOLD; setPadding(0, dp(4), 0, dp(6)); setOnClickListener { showDetails(item) } }
        card.addView(title)
        card.setOnClickListener { showDetails(item) }
        val meta = TextView(this).apply { text = "${item.date}   •   ${item.size}   •   ↑ ${item.seeds}   ↓ ${item.leeches}"; setTextColor(MUTED); textSize = 12f; setPadding(0, dp(8), 0, dp(5)) }
        card.addView(meta)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val star = TextView(this).apply { text = if (favorites.contains(item.url)) "★" else "☆"; textSize = 22f; setTextColor(if (favorites.contains(item.url)) RED else MUTED); setOnClickListener { if (!favorites.add(item.url)) favorites.remove(item.url); text = if (favorites.contains(item.url)) "★" else "☆"; setTextColor(if (favorites.contains(item.url)) RED else MUTED) } }
        actions.addView(star)
        card.addView(actions)
        list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
    }

    private fun addRemoteImage(parent: LinearLayout, url: String, poster: Boolean = false) {
        if (!url.startsWith("https://") && !url.startsWith("http://")) return
        val image = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = if (poster) "Постер" else "Скриншот"
        }
        parent.addView(image, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        val token = detailToken
        executor.execute {
            try {
                val connection = java.net.URL(url).openConnection().apply {
                    connectTimeout = 12000; readTimeout = 12000
                    setRequestProperty("User-Agent", "Mozilla/5.0")
                }
                val bitmap = connection.getInputStream().use { stream ->
                    BitmapFactory.decodeStream(stream)
                }
                runOnUiThread { if (detailOpen && token == detailToken && bitmap != null) image.setImageBitmap(bitmap) }
            } catch (_: Exception) {
                runOnUiThread { if (detailOpen && token == detailToken) parent.removeView(image) }
            }
        }
    }

    private fun showDetails(item: TorrentItem) {
        detailOpen = true
        val token = ++detailToken
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(12), dp(18), dp(30))
        }
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, -1))
        fun label(value: String, size: Float = 15f, color: Int = TEXT): TextView = TextView(this).apply {
            text = value; textSize = size; setTextColor(color); setPadding(0, dp(8), 0, dp(8))
        }
        val posterArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(posterArea)
        content.addView(label(item.title, 21f))
        content.addView(label("${item.date}   •   ${item.size}   •   ↑ ${item.seeds}   ↓ ${item.leeches}", 13f, MUTED))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(buttons)
        content.addView(label("ОПИСАНИЕ", 17f, RED))
        val descriptionArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val status = label("Загрузка описания…", 14f, MUTED)
        descriptionArea.addView(status)
        content.addView(descriptionArea)
        content.addView(label("КОММЕНТАРИИ", 17f, RED))
        val commentsArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        commentsArea.addView(label("Загрузка комментариев…", 14f, MUTED))
        content.addView(commentsArea)
        setContentView(page)
        executor.execute {
            try {
                val doc = Jsoup.connect(item.url)
                    .userAgent("Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36")
                    .timeout(20000).followRedirects(true).get()
                val magnet = doc.selectFirst("a[href^=magnet:]")?.attr("href").orEmpty()
                val torrent = doc.selectFirst("a[href$=.torrent], a[href*=download], a[href*=\"/download/\"]")?.absUrl("href")
                    ?: doc.select("a[href]").firstOrNull { it.text().contains("скачать", true) && !it.attr("href").startsWith("magnet:") }?.absUrl("href").orEmpty()
                val descriptionElement = doc.selectFirst("#details") ?: doc.selectFirst("#content") ?: doc.selectFirst("#index")
                val cleaned = descriptionElement?.clone()
                cleaned?.select("script, style, iframe, form, input, button, #comments, .comments, #comment, .comment")?.remove()
                val images = cleaned?.select("img[src]")?.map { it.absUrl("src") }
                    ?.filter { it.startsWith("https://") || it.startsWith("http://") }
                    ?.distinct()?.take(12).orEmpty()
                cleaned?.select("img")?.remove()
                // Decode HTML that the site may have escaped as text; never show raw tags.
                val rawDescription = cleaned?.text().orEmpty()
                val formattedDescription = Jsoup.parse(Jsoup.parse(rawDescription).text()).text()
                val commentNodes = doc.select("#comments .comment, #comments tr, .comments .comment, #comments > div, .comment-row, .comment")
                    .filter { it.text().isNotBlank() && it.text().length < 10000 }
                    .distinctBy { it.text() }.take(100)
                val comments = commentNodes.map { node ->
                    val author = node.selectFirst(".username, .author, .user, a[href*=profile], a[href*=user]")?.text().orEmpty()
                    val date = node.selectFirst(".date, .time, small")?.text().orEmpty()
                    Triple(author, date, node.text().trim().take(4000))
                }
                runOnUiThread {
                    if (!detailOpen || token != detailToken) return@runOnUiThread
                    if (images.isNotEmpty()) addRemoteImage(posterArea, images.first(), true)
                    if (torrent.isNotBlank()) buttons.addView(Button(this).apply {
                        text = "СКАЧАТЬ .TORRENT"; setOnClickListener { downloadTorrent(torrent, item.title) }
                    })
                    if (magnet.isNotBlank()) buttons.addView(Button(this).apply {
                        text = "ОТКРЫТЬ MAGNET"; setOnClickListener { openExternal(magnet) }
                    })
                    buttons.addView(Button(this).apply {
                        text = if (favorites.contains(item.url)) "УДАЛИТЬ ИЗ ИЗБРАННОГО" else "В ИЗБРАННОЕ"
                        setOnClickListener {
                            if (!favorites.add(item.url)) favorites.remove(item.url)
                            text = if (favorites.contains(item.url)) "УДАЛИТЬ ИЗ ИЗБРАННОГО" else "В ИЗБРАННОЕ"
                        }
                    })
                    status.text = if (formattedDescription.isBlank()) "Описание отсутствует" else ""
                    if (formattedDescription.isNotBlank()) {
                        status.text = formattedDescription.take(60000)
                        status.setTextColor(TEXT)
                    }
                    images.drop(1).forEach { addRemoteImage(descriptionArea, it) }
                    commentsArea.removeAllViews()
                    if (comments.isEmpty()) commentsArea.addView(label("Комментарии отсутствуют или недоступны на этой странице", 14f, MUTED))
                    else comments.forEach { (author, date, body) ->
                        val box = LinearLayout(this).apply {
                            orientation = LinearLayout.VERTICAL; setBackgroundColor(PANEL)
                            setPadding(dp(12), dp(10), dp(12), dp(10))
                        }
                        if (author.isNotBlank() || date.isNotBlank()) box.addView(label("$author   $date", 13f, RED))
                        box.addView(label(body, 14f))
                        commentsArea.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (detailOpen && token == detailToken) {
                        status.text = "Не удалось загрузить описание: ${e.localizedMessage}"
                        commentsArea.removeAllViews()
                        commentsArea.addView(label("Комментарии недоступны", 14f, MUTED))
                    }
                }
            }
        }
    }

    private fun returnToList() {
        detailOpen = false
        detailToken++
        setContentView(root)
    }

    @Deprecated("Handled for the native details page")
    override fun onBackPressed() {
        if (detailOpen) returnToList() else super.onBackPressed()
    }

    private fun downloadTorrent(url: String, title: String) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle(title.take(80) + ".torrent")
                .setDescription("Загрузка торрент-файла с Rutor")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "RUTOR_${System.currentTimeMillis()}.torrent")
                .setAllowedOverMetered(true).setAllowedOverRoaming(false)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            toast("Загрузка добавлена. Откройте файл из уведомления или папки Downloads.")
        } catch (e: Exception) { toast("Не удалось начать загрузку: ${e.localizedMessage}") }
    }

    private fun openExternal(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { toast("Не найдено приложение для открытия ссылки") }
    }

    private fun showFavorites() {
        val items = currentItems.filter { favorites.contains(it.url) }
        list.removeAllViews()
        (root.getChildAt(2) as? TextView)?.text = "ИЗБРАННОЕ"
        if (favorites.isEmpty()) message("Пока нет сохранённых раздач")
        else favorites.forEach { url ->
            val item = currentItems.firstOrNull { it.url == url }
            if (item != null) addTorrentCard(item) else {
                val tv = TextView(this).apply { text = url; setTextColor(TEXT); setPadding(dp(12), dp(12), dp(12), dp(12)); setOnClickListener { openExternal(url) } }
                list.addView(tv)
            }
        }
    }

    private fun showAbout() {
        android.app.AlertDialog.Builder(this).setTitle("RUTOR Native")
            .setMessage("Неофициальный клиент-каталог для Rutor. Приложение не размещает файлы и не проверяет содержимое раздач. Загружайте и распространяйте только материалы, на которые у вас есть права.")
            .setPositiveButton("OK", null).show()
    }

    private fun message(s: String) { list.addView(TextView(this).apply { text = s; setTextColor(MUTED); textSize = 14f; gravity = Gravity.CENTER; setPadding(dp(20), dp(34), dp(20), dp(34)) }) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        if (Build.VERSION.SDK_INT >= 33) {
            systemBackCallback?.let { onBackInvokedDispatcher.unregisterOnBackInvokedCallback(it) }
        }
        super.onDestroy()
        executor.shutdown()
    }
}
